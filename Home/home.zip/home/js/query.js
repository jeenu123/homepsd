$(document).ready(function(){
    $(".nav-opener").click(function(){
        $(".navigation").toggleClass("nav-active");
    });
})